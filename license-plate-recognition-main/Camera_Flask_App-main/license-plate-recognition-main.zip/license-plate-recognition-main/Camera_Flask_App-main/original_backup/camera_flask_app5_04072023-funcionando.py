from flask import Flask, render_template, Response, request
import cv2
import os, sys
import numpy as np
from threading import Thread
from pytesseract import pytesseract

path_pytesseract = r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
pytesseract.tesseract_cmd = path_pytesseract

import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

cred = credentials.Certificate(r"C:\Users\Pedro\Desktop\TCC2\license-plate-recognition-main\src\json_firebase.json")
app = firebase_admin.initialize_app(cred)
db = firestore.client()

#Deixar o codigo como esta, e utilizar a pasta de salvamento para retornar os textos
global capturar, voltar, capturahtml, editar, relatorio, sair, registrar#resultado_text, resultado_auth, resultado_confirm
capturar=0
voltar=0
capturahtml=0
editar=0
relatorio=0
sair=0
registrar=0
#resultado_text = 0
#resultado_auth = 0
#resultado_confirm = 0

camera = cv2.VideoCapture(0)

usuarios = {
    'pedro@gmail.com': '123'
}

#make shots directory to save pics
try:
    os.mkdir('./shots')
except OSError as error:
    pass

#Load pretrained face detection model    
#net = cv2.dnn.readNetFromCaffe('./Camera_Flask_App-main/saved_model/deploy.prototxt.txt', './Camera_Flask_App-main/saved_model/res10_300x300_ssd_iter_140000.caffemodel')

#instatiate flask app  
app = Flask(__name__, template_folder='./templates')

def registrar_placa(placa,nome,apto):

    data = {apto: apto,
            nome: nome}
    db.collection(u'plates').document(placa).set(data)

    data = {
        u'entrada': 'null',
        u'saida': 'null',
        u'nova_entrada': 'null',
        u'acessos': 0,
    }
    db.collection(u'historico_ref').document(placa).set(data)
    return 'Registrado no banco!'


def hist_ref(plates_numbers):
    db_ = db.collection(u'historico_ref').document(plates_numbers)
    
    acessos_ = db_.get({u'acessos'})
    entrada_ = db_.get({u'entrada'})
    saida_ = db_.get({u'saida'})
    novaentrada_ = db_.get({u'nova_entrada'})
 

    if acessos_.exists:
        data = acessos_.to_dict()
        for value in data.values():
            a = str(value)

    if entrada_.exists:
        data = entrada_.to_dict()
        for value in data.values():
            e = str(value)
            e = e[:19]

    if saida_.exists:
        data = saida_.to_dict()
        for value in data.values():
            s = str(value)
            s = s[:19]

    if novaentrada_.exists:
        data = novaentrada_.to_dict()
    for value in data.values():
        ne = str(value)
        ne = ne[:19]

        #print(f"\n",plates_numbers,":")
        print("Acessos:", a)
        print("Entrada:", e)
        print("Saida:", s)
        print("Nova Entrada:", ne,"\n")
        

        #histref = f"{plates_numbers}:\n"
        histref = f"Acessos: {a}\n"
        histref += f"Entrada: {e}\n"
        histref += f"Saida: {s}\n"
        histref += f"Nova Entrada: {ne}\n"
        return histref


def registrar_entrada_saida(plates_numbers):
    db_ = db.collection(u'historico_ref').document(plates_numbers)
    #db_a = db.collection(u'historico_ref').document(u'CSC-2013').get({u'acessos'})
    
    acessos_ = db_.get({u'acessos'})
    entrada_ = db_.get({u'entrada'})
    saida_ = db_.get({u'saida'})
    novaentrada_ = db_.get({u'nova_entrada'})




    if acessos_.exists:
        acs = acessos_.to_dict()
        for value in acs.values():
            acs = value
    else: 
        db_.set({u'acessos': 0})
        acs = 0

    if entrada_.exists:
        ent = entrada_.to_dict()
        for value in ent.values():
            ent = value


    if saida_.exists:
        sai = saida_.to_dict()
        for value in sai.values():
            sai = value


    if novaentrada_.exists:
        nen = novaentrada_.to_dict()
        for value in nen.values():
            nen = value


    #plates_numbers = 'CSC-2013'
    report1= hist_ref(plates_numbers)

    if ent == 'null':
        reg_acesso = int(acs)+1
        registro_entrada = {
            'entrada': firestore.SERVER_TIMESTAMP,
            'saida': 'null',
            'nova_entrada': 'null',
            'acessos': reg_acesso
        }
        
        #mais_um_acesso = {'acessos': reg_acesso}
        db_.update(registro_entrada)
        #db_a.set( mais_um_acesso)
        confirmation = 'Entrada registrada com sucesso!'
        report2= hist_ref(plates_numbers)
    elif sai == 'null':
        registro_saida = {
            'saida': firestore.SERVER_TIMESTAMP
        }
        #historico_ref.add(registro_saida)
        db_.update(registro_saida)
        confirmation = 'Saída registrada com sucesso!'
        report2= hist_ref(plates_numbers)
    elif nen == 'null':
        reg_acesso = int(acs)+1
        registro_nova_entrada = {
            'nova_entrada': firestore.SERVER_TIMESTAMP,
            'acessos': reg_acesso
        }
        #historico_ref.add(registro_saida)
        db_.update(registro_nova_entrada)
        print()
        confirmation = 'Já existem uma entrada e uma saída registradas. Nova entrada registrada com sucesso!'
        report2= hist_ref(plates_numbers)
    else: 
        novo_registro = {
        'entrada': nen,
        'saida': firestore.SERVER_TIMESTAMP,
        'nova_entrada': 'null',
}
        db_.update(novo_registro)
        confirmation = 'Novo registro adicionado. Saída registrada com sucesso!'
        report2= hist_ref(plates_numbers)

        resultados = {
        'report1': report1,
        'confirmation': confirmation,
        'report2': report2
    }
        return resultados


def check_value(plates_numbers):
    valor = plates_numbers
    #print(valor)
    doc_ref = db.collection(u'plates').document(valor)
    doc = doc_ref.get()
    if doc.exists:
        print('AUTHORIZED')
        return 'AUTHORIZED'
    else:
        print('NOT AUTHORIZED')
        return 'NOT AUTHORIZED'  
 

def gen_frames():  # generate frame by frame from camera
    global out, capturar,rec_frame
    while True:
        success, frame = camera.read() 
       
        if success:
            if(capturar):
                capturar=0
                p = os.path.sep.join(['shots', "captura.jpg"])
                cv2.imwrite(p, frame)
            
            
            
                
            try:
                ret, buffer = cv2.imencode('.jpg', frame)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            except Exception as e:
                pass
                
        else:
            pass


def scan_plate(image):
    custom_config = r"-c tessedit_char_blacklist=abcdefghijklmnopqrstuvwxyz/ --psm 6"
    plate_number = (pytesseract.image_to_string(image, config=custom_config))
    return plate_number[:-1]


def retornar_texto():

    directory = r"C:\Users\Pedro\Desktop\TCC2\license-plate-recognition-main\shots"
    filenames_ = next(os.walk(directory))[2]
    images = [os.path.join(directory, filename) for filename in filenames_]
    plates = []
    plates_numbers = []
    data = []
    _, _, filenames = next(os.walk(directory))
    
    for i in range(len(filenames)):
        data.append([])
        data[i].append(filenames[i])

    for image_path in images:
        plates.append(cv2.imread(image_path))

    for i in range(len(plates)):
        plates_numbers.append(scan_plate(plates[i]))
        my_string = str(plates_numbers)
        replacements = [("['", ''),("']", ''),("“",''), ('?', ''),('#', ''),  
                    ('¨', ''),('&', ''), ('*', ''),(')', ''), ('(', ''), ('@', ''),
                    ('-', ''), ('_', ''),(' ', ''), ('"', ''),('+', ''), ('%', ''),
                    ('=', ''), ('//', ''),('|', ''), ('>', ''),(':', ''),
                    ('<', ''), ("~", ''),(',', ''), ('.', ''),('°', ''),
                    (';', ''),('«', ''), ("—", ''),('“', ''),('^', ''),
                    ('\\n', ''),(']', ''),('[', ''),('¢', ''),('$', ''),
                    ('£', ''),('§', ''),('‘', ''),('©', ''),('/', ''),('!', ''),
                    ("'", ''),("////", ''),("\/", ''),("//\\", ''),("——", ''),
                    ('¥', ''),("['", ''),("']", ''),("|", ""),(" “", '')]
        for char, replacement in replacements:
            if char in my_string:
                my_string = my_string.replace(char, replacement)
                plates_numbers = my_string[:7]
                print(plates_numbers)
                return plates_numbers




@app.route('/')
def index():
    return render_template('login.html')#captura.html
    
@app.route('/read_text')
def read_text():
    texto_lido = retornar_texto()  # Chama a função para obter o texto lido
    return render_template('captura_realizada.html', texto=texto_lido)


@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/requests',methods=['POST','GET'])
def tasks():
    global camera


    if request.method == 'POST':
        if request.form.get('click') == 'Capturar':
            global capturar
            capturar=1
            try:
                texto_lido = retornar_texto()
                authorization = check_value(texto_lido)
                if authorization == "AUTHORIZED":
                    resultados = registrar_entrada_saida(texto_lido)
                    report1 = resultados['report1']
                    confirmation = resultados['confirmation']
                    report2 = resultados['report2']
                    return render_template('captura_realizada.html', texto=texto_lido, auth=authorization,report1=report1,confirmation=confirmation,report2=report2)
                else:
                    report1 = ''
                    confirmation = ''
                    report2 = ''
                    return render_template('captura_realizada.html', texto=texto_lido, auth=authorization,report1=report1,confirmation=confirmation,report2=report2)
            except Exception as e:
                error_message = f"Ocorreu um erro: {str(e)}"
                return render_template('captura_realizada.html', error_message=error_message)


    if request.method == 'POST':
        if request.form.get('click') == 'Registar':
            global registrar
            registrar=1
            return render_template('cadastro.html')


    if request.method == 'POST':
        if request.form.get('click') == 'Captura':
            global capturahtml
            capturahtml=1
            return render_template('captura.html')                
                          

    if request.method == 'POST':
        if request.form.get('click') == 'Relatório':
            global relatorio
            relatorio=1
            return render_template('relatorio.html')


    if request.method == 'POST':
        if request.form.get('click') == 'Sair':
            global sair
            sair=1
            return render_template('login.html')


    if request.method == 'POST':
        if request.form.get('click') == 'Voltar':
            global voltar
            voltar=1
            return render_template('menu.html')                
                 
    elif request.method=='GET':
        return render_template('menu.html')
    return render_template('menu.html')


@app.route('/login', methods=['POST'])
def login():
    nome = request.form.get('nome')
    senha = request.form.get('senha')


    if nome in usuarios and usuarios[nome] == senha:

        return render_template('menu.html')
    else:
        return render_template('login.html')
    



@app.route('/cadastro', methods=['POST'])
def cadastro():
    placa = request.form.get('placa')
    nome = request.form.get('nome')
    apto = request.form.get('apto')
    registrar_placa(placa,nome,apto)
    apto = "222"
    return Response(registrar_placa(placa,nome,apto)), render_template('menu.html')





if __name__ == '__main__':
    app.run()
    
camera.release()
cv2.destroyAllWindows()     