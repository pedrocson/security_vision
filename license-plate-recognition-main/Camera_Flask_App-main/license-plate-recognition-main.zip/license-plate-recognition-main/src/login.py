from flask import Flask, render_template, redirect, request

app = Flask(__name__)
app.config['SECRET_KEY'] = "SENHA"


usuarios = {
    'pedro@gmail.com': '123'
}

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    nome = request.form.get('nome')
    senha = request.form.get('senha')


    if nome in usuarios and usuarios[nome] == senha:

        print('usurio:' + nome)
        print("SENHA:" + senha)

        return render_template('menu.html')
    else:
        print('usurio errado:' + nome)
        print("SENHA errada :" + senha)
        return render_template('login.html')
        
    #return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)